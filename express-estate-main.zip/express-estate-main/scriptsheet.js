function buyNow(){
    
}